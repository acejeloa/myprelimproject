@extends('base')

@section('content')

<br>
<h1>Welcome to Twikker!</h1>
<h5>
  Share your feelings to the world.
</h5>



<style>
  body{
    object-fit: contain;
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100vh;
  }

</style>
@endsection
