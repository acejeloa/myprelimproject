@extends('base')
@section('content')

   
    <livewire:posts.edit :postId="$id"/>
    
@endsection
