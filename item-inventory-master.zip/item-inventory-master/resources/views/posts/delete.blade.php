@extends('base')

@section('content')

<livewire:posts.delete :postId="$id"/>

@endsection