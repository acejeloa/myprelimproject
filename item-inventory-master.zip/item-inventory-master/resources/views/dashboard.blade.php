@extends('base')

@section('content')

<br>
<h1>Hello</h1>

@endsection
